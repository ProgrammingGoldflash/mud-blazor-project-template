﻿using AutoMapper;

namespace $safeprojectname$.Profiles
{
    public class ModelProfile : Profile
    {
    }
}